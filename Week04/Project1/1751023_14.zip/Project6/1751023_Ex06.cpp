#include "Struct.h"

int main()
{
	Node *head = NULL;
	load("D:\\APCS\\CS162\\Week04\\input.txt", head);
	listtonumb(head);
	system("pause");
	return 0;
}